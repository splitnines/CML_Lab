{
  "subject": {{ toJson .Subject }},
  "sans": {{ toJson .SANs }},
  {{- if typeIs "*rsa.PublicKey" .Insecure.CR.PublicKey }}
  "keyUsage": ["digitalSignature", "keyEncipherment"],
  {{- else }}
  {{ fail "Key type must be RSA" }}
  {{- end }}
  "extKeyUsage": ["serverAuth", "clientAuth"]
}
