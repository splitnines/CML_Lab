pwd
ls
cd /var/log
ls
cd
ls
cd /var
l
ls
cd lib
ls
cd misc
ls
cd ..
ls
cd ..
ls
exit
